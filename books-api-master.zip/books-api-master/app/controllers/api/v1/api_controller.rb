module Api::V1
  class ApiController < ApplicationController
    # Generic API stuff here
  end
end